import { View, Text, StyleSheet, TouchableOpacity, TextInput } from 'react-native';
import { Link } from 'expo-router';
import { Sparkles, AtSign, KeyRound } from 'lucide-react-native';

export default function LoginScreen() {
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Sparkles size={48} color="#6366F1" />
        <Text style={styles.title}>NovaLink</Text>
        <Text style={styles.subtitle}>Where creativity meets connection</Text>
      </View>

      <View style={styles.form}>
        <View style={styles.inputWrapper}>
          <View style={styles.inputContainer}>
            <AtSign size={20} color="#6366F1" />
            <TextInput
              placeholder="Email"
              placeholderTextColor="#94A3B8"
              style={styles.input}
            />
          </View>
          <View style={styles.inputHighlight} />
        </View>
        
        <View style={styles.inputWrapper}>
          <View style={styles.inputContainer}>
            <KeyRound size={20} color="#6366F1" />
            <TextInput
              placeholder="Password"
              placeholderTextColor="#94A3B8"
              secureTextEntry
              style={styles.input}
            />
          </View>
          <View style={styles.inputHighlight} />
        </View>

        <TouchableOpacity style={styles.loginButton}>
          <Text style={styles.loginButtonText}>Join the Community</Text>
        </TouchableOpacity>

        <Link href="/(tabs)" style={styles.skipLink}>
          <Text style={styles.skipText}>Explore as Guest</Text>
        </Link>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
    padding: 24,
  },
  header: {
    marginTop: 80,
    alignItems: 'center',
    gap: 12,
  },
  title: {
    fontFamily: 'Inter-Bold',
    fontSize: 36,
    color: '#1E293B',
    letterSpacing: -1,
  },
  subtitle: {
    fontFamily: 'Inter-Regular',
    fontSize: 16,
    color: '#64748B',
  },
  form: {
    marginTop: 48,
    gap: 24,
  },
  inputWrapper: {
    position: 'relative',
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 16,
    gap: 12,
  },
  inputHighlight: {
    position: 'absolute',
    bottom: 0,
    left: '10%',
    width: '80%',
    height: 3,
    backgroundColor: '#6366F1',
    borderRadius: 1.5,
    opacity: 0.3,
  },
  input: {
    flex: 1,
    fontFamily: 'Inter-Regular',
    fontSize: 16,
    color: '#1E293B',
  },
  loginButton: {
    backgroundColor: '#6366F1',
    borderRadius: 16,
    padding: 16,
    alignItems: 'center',
    marginTop: 8,
    shadowColor: '#6366F1',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 4,
  },
  loginButtonText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 16,
    color: '#fff',
  },
  skipLink: {
    alignItems: 'center',
    marginTop: 16,
  },
  skipText: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: '#64748B',
  },
});