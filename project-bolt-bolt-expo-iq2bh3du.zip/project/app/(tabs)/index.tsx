import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { Image } from 'expo-image';
import { Heart, MessageCircle, Share } from 'lucide-react-native';

const posts = [
  {
    id: 1,
    user: {
      name: 'Sarah Wilson',
      avatar: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg',
    },
    image: 'https://images.pexels.com/photos/2014422/pexels-photo-2014422.jpeg',
    likes: 234,
    comments: 18,
    caption: 'Beautiful sunset at the beach! 🌅',
  },
  {
    id: 2,
    user: {
      name: 'Mike Johnson',
      avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg',
    },
    image: 'https://images.pexels.com/photos/1181671/pexels-photo-1181671.jpeg',
    likes: 156,
    comments: 12,
    caption: 'Coffee and code, perfect morning! ☕️💻',
  },
];

export default function HomeScreen() {
  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.logo}>NovaLink</Text>
      </View>

      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={styles.stories}>
        {posts.map(post => (
          <TouchableOpacity key={post.id} style={styles.story}>
            <Image
              source={post.user.avatar}
              style={styles.storyAvatar}
              contentFit="cover"
            />
            <Text style={styles.storyName}>{post.user.name.split(' ')[0]}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {posts.map(post => (
        <View key={post.id} style={styles.post}>
          <View style={styles.postHeader}>
            <Image
              source={post.user.avatar}
              style={styles.postAvatar}
              contentFit="cover"
            />
            <Text style={styles.postUsername}>{post.user.name}</Text>
          </View>

          <Image
            source={post.image}
            style={styles.postImage}
            contentFit="cover"
          />

          <View style={styles.postActions}>
            <TouchableOpacity>
              <Heart size={24} color="#666" />
            </TouchableOpacity>
            <TouchableOpacity>
              <MessageCircle size={24} color="#666" />
            </TouchableOpacity>
            <TouchableOpacity>
              <Share size={24} color="#666" />
            </TouchableOpacity>
          </View>

          <View style={styles.postFooter}>
            <Text style={styles.likes}>{post.likes} likes</Text>
            <Text style={styles.caption}>
              <Text style={styles.username}>{post.user.name}</Text> {post.caption}
            </Text>
            <Text style={styles.comments}>
              View all {post.comments} comments
            </Text>
          </View>
        </View>
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  header: {
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
    marginTop: 44,
  },
  logo: {
    fontFamily: 'Inter-Bold',
    fontSize: 24,
    color: '#000',
  },
  stories: {
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  story: {
    alignItems: 'center',
    marginRight: 16,
  },
  storyAvatar: {
    width: 64,
    height: 64,
    borderRadius: 32,
    marginBottom: 4,
    backgroundColor: '#eee',
  },
  storyName: {
    fontFamily: 'Inter-Regular',
    fontSize: 12,
    color: '#666',
  },
  post: {
    marginBottom: 16,
  },
  postHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
  },
  postAvatar: {
    width: 32,
    height: 32,
    borderRadius: 16,
    marginRight: 8,
    backgroundColor: '#eee',
  },
  postUsername: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 14,
    color: '#000',
  },
  postImage: {
    width: '100%',
    height: 400,
    backgroundColor: '#eee',
  },
  postActions: {
    flexDirection: 'row',
    padding: 16,
    gap: 16,
  },
  postFooter: {
    padding: 16,
    paddingTop: 0,
  },
  likes: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 14,
    color: '#000',
    marginBottom: 4,
  },
  caption: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: '#000',
    marginBottom: 4,
  },
  username: {
    fontFamily: 'Inter-SemiBold',
  },
  comments: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: '#666',
  },
});