import { View, Text, StyleSheet, TextInput, ScrollView } from 'react-native';
import { Image } from 'expo-image';
import { Search as SearchIcon } from 'lucide-react-native';

const posts = [
  'https://images.pexels.com/photos/2014422/pexels-photo-2014422.jpeg',
  'https://images.pexels.com/photos/1181671/pexels-photo-1181671.jpeg',
  'https://images.pexels.com/photos/3225517/pexels-photo-3225517.jpeg',
  'https://images.pexels.com/photos/2387873/pexels-photo-2387873.jpeg',
  'https://images.pexels.com/photos/1181677/pexels-photo-1181677.jpeg',
  'https://images.pexels.com/photos/1181675/pexels-photo-1181675.jpeg',
];

export default function SearchScreen() {
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View style={styles.searchBar}>
          <SearchIcon size={20} color="#666" />
          <TextInput
            placeholder="Search"
            style={styles.searchInput}
            placeholderTextColor="#666"
          />
        </View>
      </View>

      <ScrollView>
        <View style={styles.grid}>
          {posts.map((post, index) => (
            <Image
              key={index}
              source={post}
              style={styles.gridItem}
              contentFit="cover"
            />
          ))}
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  header: {
    padding: 16,
    marginTop: 44,
  },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f5f5f5',
    borderRadius: 8,
    padding: 8,
    gap: 8,
  },
  searchInput: {
    flex: 1,
    fontFamily: 'Inter-Regular',
    fontSize: 16,
  },
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  gridItem: {
    width: '33.33%',
    aspectRatio: 1,
    backgroundColor: '#eee',
  },
});