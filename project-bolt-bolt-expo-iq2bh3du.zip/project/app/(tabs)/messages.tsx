import { View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput } from 'react-native';
import { Image } from 'expo-image';
import { Search, Plus, TrendingUp, Users, Gamepad2, Music, Code, Camera } from 'lucide-react-native';

const spaces = [
  {
    id: 1,
    name: 'Photography',
    members: 12453,
    icon: Camera,
    cover: 'https://images.pexels.com/photos/1779487/pexels-photo-1779487.jpeg',
    trending: true,
  },
  {
    id: 2,
    name: 'Gaming',
    members: 8234,
    icon: Gamepad2,
    cover: 'https://images.pexels.com/photos/3165335/pexels-photo-3165335.jpeg',
    trending: true,
  },
  {
    id: 3,
    name: 'Music',
    members: 6129,
    icon: Music,
    cover: 'https://images.pexels.com/photos/1626481/pexels-photo-1626481.jpeg',
    trending: false,
  },
  {
    id: 4,
    name: 'Developers',
    members: 4521,
    icon: Code,
    cover: 'https://images.pexels.com/photos/2004161/pexels-photo-2004161.jpeg',
    trending: false,
  },
];

export default function SpacesScreen() {
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Spaces</Text>
        <TouchableOpacity style={styles.createButton}>
          <Plus size={24} color="#6366F1" />
        </TouchableOpacity>
      </View>

      <View style={styles.searchContainer}>
        <Search size={20} color="#94A3B8" />
        <TextInput
          placeholder="Search spaces"
          placeholderTextColor="#94A3B8"
          style={styles.searchInput}
        />
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <View style={styles.sectionTitle}>
              <TrendingUp size={20} color="#6366F1" />
              <Text style={styles.sectionTitleText}>Trending Spaces</Text>
            </View>
            <TouchableOpacity>
              <Text style={styles.seeAllText}>See All</Text>
            </TouchableOpacity>
          </View>

          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            style={styles.trendingList}>
            {spaces
              .filter(space => space.trending)
              .map(space => (
                <TouchableOpacity key={space.id} style={styles.trendingCard}>
                  <Image source={space.cover} style={styles.trendingCover} contentFit="cover" />
                  <View style={styles.trendingOverlay}>
                    <space.icon size={24} color="#fff" />
                    <Text style={styles.trendingName}>{space.name}</Text>
                    <View style={styles.memberCount}>
                      <Users size={14} color="#fff" />
                      <Text style={styles.memberCountText}>
                        {space.members.toLocaleString()}
                      </Text>
                    </View>
                  </View>
                </TouchableOpacity>
              ))}
          </ScrollView>
        </View>

        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitleText}>All Spaces</Text>
          </View>

          {spaces.map(space => (
            <TouchableOpacity key={space.id} style={styles.spaceItem}>
              <Image source={space.cover} style={styles.spaceItemCover} contentFit="cover" />
              <View style={styles.spaceItemInfo}>
                <space.icon size={20} color="#6366F1" />
                <View style={styles.spaceItemText}>
                  <Text style={styles.spaceItemName}>{space.name}</Text>
                  <View style={styles.spaceItemMembers}>
                    <Users size={14} color="#94A3B8" />
                    <Text style={styles.spaceItemMembersText}>
                      {space.members.toLocaleString()} members
                    </Text>
                  </View>
                </View>
              </View>
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 24,
    paddingTop: 48,
    backgroundColor: '#fff',
  },
  title: {
    fontFamily: 'Inter-Bold',
    fontSize: 24,
    color: '#1E293B',
  },
  createButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#EEF2FF',
    alignItems: 'center',
    justifyContent: 'center',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    margin: 24,
    marginTop: 0,
    padding: 12,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  searchInput: {
    flex: 1,
    marginLeft: 8,
    fontFamily: 'Inter-Regular',
    fontSize: 16,
    color: '#1E293B',
  },
  content: {
    flex: 1,
  },
  section: {
    marginBottom: 24,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 24,
    marginBottom: 16,
  },
  sectionTitle: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  sectionTitleText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 18,
    color: '#1E293B',
  },
  seeAllText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 14,
    color: '#6366F1',
  },
  trendingList: {
    paddingLeft: 24,
  },
  trendingCard: {
    width: 200,
    height: 250,
    marginRight: 16,
    borderRadius: 16,
    overflow: 'hidden',
  },
  trendingCover: {
    width: '100%',
    height: '100%',
  },
  trendingOverlay: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    padding: 16,
    backgroundColor: 'rgba(0,0,0,0.4)',
    alignItems: 'center',
    gap: 8,
  },
  trendingName: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 16,
    color: '#fff',
  },
  memberCount: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  memberCountText: {
    fontFamily: 'Inter-Medium',
    fontSize: 12,
    color: '#fff',
  },
  spaceItem: {
    flexDirection: 'row',
    marginHorizontal: 24,
    marginBottom: 16,
    padding: 12,
    backgroundColor: '#fff',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  spaceItemCover: {
    width: 64,
    height: 64,
    borderRadius: 8,
  },
  spaceItemInfo: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    marginLeft: 12,
    gap: 12,
  },
  spaceItemText: {
    flex: 1,
  },
  spaceItemName: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 16,
    color: '#1E293B',
    marginBottom: 4,
  },
  spaceItemMembers: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  spaceItemMembersText: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: '#94A3B8',
  },
});