import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { Image } from 'expo-image';
import { Settings, Grid2x2 as Grid, Bookmark } from 'lucide-react-native';

export default function ProfileScreen() {
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.username}>Sarah Wilson</Text>
        <TouchableOpacity>
          <Settings size={24} color="#000" />
        </TouchableOpacity>
      </View>

      <ScrollView>
        <View style={styles.profile}>
          <Image
            source="https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg"
            style={styles.avatar}
            contentFit="cover"
          />
          <View style={styles.stats}>
            <View style={styles.stat}>
              <Text style={styles.statNumber}>128</Text>
              <Text style={styles.statLabel}>Posts</Text>
            </View>
            <View style={styles.stat}>
              <Text style={styles.statNumber}>1,284</Text>
              <Text style={styles.statLabel}>Followers</Text>
            </View>
            <View style={styles.stat}>
              <Text style={styles.statNumber}>947</Text>
              <Text style={styles.statLabel}>Following</Text>
            </View>
          </View>

          <Text style={styles.bio}>
            Photography enthusiast 📸{'\n'}
            Travel lover ✈️{'\n'}
            Coffee addict ☕️
          </Text>

          <TouchableOpacity style={styles.editButton}>
            <Text style={styles.editButtonText}>Edit Profile</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.tabs}>
          <TouchableOpacity style={[styles.tab, styles.activeTab]}>
            <Grid size={24} color="#000" />
          </TouchableOpacity>
          <TouchableOpacity style={styles.tab}>
            <Bookmark size={24} color="#666" />
          </TouchableOpacity>
        </View>

        <View style={styles.posts}>
          {Array(9).fill(0).map((_, index) => (
            <Image
              key={index}
              source={`https://images.pexels.com/photos/${2014422 + index}/pexels-photo-${2014422 + index}.jpeg`}
              style={styles.post}
              contentFit="cover"
            />
          ))}
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    marginTop: 44,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  username: {
    fontFamily: 'Inter-Bold',
    fontSize: 24,
    color: '#000',
  },
  profile: {
    padding: 16,
  },
  avatar: {
    width: 96,
    height: 96,
    borderRadius: 48,
    marginBottom: 16,
    backgroundColor: '#eee',
  },
  stats: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginBottom: 16,
  },
  stat: {
    alignItems: 'center',
  },
  statNumber: {
    fontFamily: 'Inter-Bold',
    fontSize: 18,
    color: '#000',
  },
  statLabel: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: '#666',
  },
  bio: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: '#000',
    marginBottom: 16,
  },
  editButton: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    padding: 8,
    alignItems: 'center',
  },
  editButtonText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 14,
    color: '#000',
  },
  tabs: {
    flexDirection: 'row',
    borderTopWidth: 1,
    borderTopColor: '#eee',
  },
  tab: {
    flex: 1,
    alignItems: 'center',
    padding: 12,
  },
  activeTab: {
    borderBottomWidth: 2,
    borderBottomColor: '#000',
  },
  posts: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  post: {
    width: '33.33%',
    aspectRatio: 1,
    backgroundColor: '#eee',
  },
});